# Minecraft SPH
Explicit SPH solver Minecraft Mod 

## Before you begin
If you just want to downaload and install the mod to play with it on Minecraft you will need Forge, look at this [*link*](https://youtu.be/71Co8ygepxo) .
And the only file you need from this repository is the .jar file. 


If you want to edit the mod then you do need all the files in this repository. The mod was created using [*Mcreator*](https://mcreator.net/). Thus, we recommend that you install Mcreator to edit the code. 

## Contact us 

If you download and use the mod, please shoot us an email with a screenshot of your activitiy at abuganza .at. purdue.edu 
